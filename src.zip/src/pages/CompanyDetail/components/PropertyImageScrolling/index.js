import { PropertyImageScrollingWrapper } from "./styles";


export const PropertyImageScrolling = () =>(

    
        <PropertyImageScrollingWrapper>
            <img alt="logo" src="https://static.rfstat.com/renderforest/images/v2/landing-pics/logo_landing/bakery/bakery_logo_3.png"/>
        </PropertyImageScrollingWrapper>






)