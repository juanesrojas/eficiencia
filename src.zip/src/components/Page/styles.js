import styled from 'styled-components';
import { MENU_HEIGHT } from '../../constants/styleConstants';

export const PageWrapper = styled.section`
    margin: 10px auto ${MENU_HEIGHT+10}px; 
    width:80%;
    //margin:auto;


   
`;