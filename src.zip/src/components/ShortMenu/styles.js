import styled from 'styled-components';

export const BackButtonWrapper = styled.div`

   

    

    border: 1px;
    background-color:white;
    border-radius: 10px;
    align-items: center;
    //width:100%;
    margin:0px 0px;
    padding:0px;
    display:flex;





    .icon-container{
        flex:1;
        margin:0px 2px;
        padding:0px;
        display:flex;
        align-items: center;
        justify-content: center;

    };

    

   
    
    .middle-space{
        flex:20;


    };
    

`