import styled from 'styled-components';

export const PropertyInfoWrapper=styled.div`
   
    border-radius: 10px;
    margin-top:0;
    margin-left: 10px;
    flex:70;
    h3 {
        margin:0;
    }
`;