
import { PropertyBusinessType } from "../PropertyBusinessType";
import { PropertyTypeLabel } from "../PropertyTypeLabel";
import { PropertyInfoWrapper } from "./styles";
import { FaHandshake,FaBuilding } from 'react-icons/fa';
import { Title, SubTitle, SecondaryText } from "../../globalStyles";
import { SquaredButton } from "../Button";
import { FaHome,FaArrowLeft,FaAvianex,FaPen } from 'react-icons/fa';


export const CompanyInfoCard = ({companyName,nit}) =>(

        <PropertyInfoWrapper>
            <Title>{companyName}</Title>
            <SecondaryText>Nit: {nit}</SecondaryText>
            <PropertyTypeLabel icon={FaBuilding} typeId={"Alimentos"} />
            <PropertyBusinessType icon={FaHandshake} typeId={"Medellín"}/>
            <div className="icon-container"> <SquaredButton icon={FaPen} link="/companydetail" />  </div>

        </PropertyInfoWrapper>




    







)