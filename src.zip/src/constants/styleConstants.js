export const MENU_HEIGHT = 80;
export const PRIMARY_COLOR = '#194d33';
export const SECONDARY_COLOR = '#BFE0D0';